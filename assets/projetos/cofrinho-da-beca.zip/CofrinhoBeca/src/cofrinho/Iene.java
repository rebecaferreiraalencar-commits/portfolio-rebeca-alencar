package cofrinho;

/*Classe que representa a moeda Iene.*/
public class Iene extends Moeda {

    //Taxa de conversão usada para transformar Iene em Real
    private static final double TAXA_CONVERSAO = 6.33;

    /*Recebe o valor em iene que quer adicionar no cofrinho.*/
    public Iene(double valor) {
        super(valor);
    }

    /*Converte o valor para reais.
     * Fórmula: valor do iene × taxa de conversão.*/
    @Override
    public double converterParaReal() {
        return valor * TAXA_CONVERSAO;
    }

    @Override
    public String info() {
        return "Iene - ¥: " + valor;

    }
}
