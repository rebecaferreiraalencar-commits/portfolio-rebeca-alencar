package cofrinho;

public abstract class Moeda {

    protected double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    // Cada moeda deve dizer como converte para real
    public abstract double converterParaReal();

    // Mostra info da moeda
    public abstract String info();
}
