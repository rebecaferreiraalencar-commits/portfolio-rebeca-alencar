package cofrinho;

/*Classe que representa a moeda Dólar.*/
public class Dolar extends Moeda {

    //Taxa de conversão usada para transformar Dólar em Real
    private static final double TAXA_CONVERSAO = 5.31;

    /*Recebe o valor em dólar que quer adicionar no cofrinho.*/
    public Dolar(double valor) {
        super(valor);
    }

    /*Converte o valor para reais.
     * Fórmula: valor do dólar × taxa de conversão.*/
    @Override
    public double converterParaReal() {
        return valor * TAXA_CONVERSAO;
    }

    @Override
    public String info() {
        return "Dólar - US$: " + valor;
    }
}
