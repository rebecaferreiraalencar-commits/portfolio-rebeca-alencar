package cofrinho;

import java.util.ArrayList;

/* Classe que representa o cofrinho. 
 * Ele guarda uma lista de moedas e permite adicionar moedas, remover moedas, listar, calcular o total em reais*/
public class Cofrinho {

    //Lista onde guardamos todas as moedas adicionadas
    private ArrayList<Moeda> listaMoedas = new ArrayList<>();

    /*Adiciona uma moeda dentro do cofrinho.*/
    public void adicionar(Moeda moeda) {
        listaMoedas.add(moeda);
    }

    /* Remove uma moeda do cofrinho.*/
    public boolean remover(Moeda moeda) {
        for (int i = 0; i < listaMoedas.size(); i++) {
            Moeda m = listaMoedas.get(i);

            //Compara o tipo e o valor aproximado/
            if (m.getClass() == moeda.getClass() && Math.abs(m.getValor() - moeda.getValor()) < 0.0001) {
                listaMoedas.remove(i);
                return true;
            }
        }
        return false;
    }

    /*Lista todas as moedas que estão no cofrinho.*/
    public void listarMoedas() {
        if (listaMoedas.isEmpty()) {
            System.out.println("O cofrinho está vazio!");
            return;
        }

        for (Moeda m : listaMoedas) {
            System.out.println(m.info());
        }
    }

    /*Soma todas as moedas convertidas para Real.*/
    public double calcularTotal() {
        double total = 0;

        for (Moeda m : listaMoedas) {
            total += m.converterParaReal();
        }

        return total;
    }
}
