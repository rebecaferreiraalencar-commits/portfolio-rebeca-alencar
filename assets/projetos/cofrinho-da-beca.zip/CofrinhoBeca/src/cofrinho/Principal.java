package cofrinho;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Cofrinho cofrinho = new Cofrinho();
        Scanner scanner = new Scanner(System.in);

        int opcao;

        do {
        	System.out.println("\n============================");
            System.out.println("|| 💜 COFRINHO DA BECA 💜 ||");
            System.out.println("============================");
            System.out.println("1 - Adicionar moeda");
            System.out.println("2 - Remover moeda");
            System.out.println("3 - Listar moedas");
            System.out.println("4 - Calcular total em Reais");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {

                case 1: // Adicionar moeda
                    System.out.println("1 - Real");
                    System.out.println("2 - Dólar");
                    System.out.println("3 - Euro");
                    System.out.println("4 - Iene");
                    System.out.println("Escolha o tipo da moeda:");
                    int tipoAdicionar = scanner.nextInt();
                    System.out.print("Digite o valor da moeda: ");
                    double valorAdicionar = scanner.nextDouble();

                    Moeda moedaParaAdicionar = null;
                    switch (tipoAdicionar) {
                        case 1: moedaParaAdicionar = new Real(valorAdicionar); break;
                        case 2: moedaParaAdicionar = new Dolar(valorAdicionar); break;
                        case 3: moedaParaAdicionar = new Euro(valorAdicionar); break;
                        case 4: moedaParaAdicionar = new Iene(valorAdicionar); break;
                        default: System.out.println("Tipo de moeda inválido!");
                    }

                    if (moedaParaAdicionar != null) {
                        cofrinho.adicionar(moedaParaAdicionar);
                        System.out.println("Moeda adicionada!");
                    }
                    break;

                case 2: // Remover moeda
                    System.out.println("Escolha o tipo da moeda que deseja remover:");
                    System.out.println("1 - Real");
                    System.out.println("2 - Dólar");
                    System.out.println("3 - Euro");
                    System.out.println("4 - Iene");
                    int tipoRemover = scanner.nextInt();
                    System.out.print("Digite o valor da moeda: ");
                    double valorRemover = scanner.nextDouble();

                    Moeda moedaParaRemover = null;
                    switch (tipoRemover) {
                        case 1: moedaParaRemover = new Real(valorRemover); break;
                        case 2: moedaParaRemover = new Dolar(valorRemover); break;
                        case 3: moedaParaRemover = new Euro(valorRemover); break;
                        case 4: moedaParaRemover = new Iene(valorRemover); break;
                        default: System.out.println("Tipo de moeda inválido!");
                    }

                    if (moedaParaRemover != null) {
                        boolean removido = cofrinho.remover(moedaParaRemover);
                        if (removido) {
                            System.out.println("Moeda removida com sucesso!");
                        } else {
                            System.out.println("Moeda não encontrada!");
                        }
                    }
                    break;

                case 3: // Listar moedas
                    cofrinho.listarMoedas();
                    break;

                case 4: // Calcular total
                    double total = cofrinho.calcularTotal();
                    System.out.printf("Total em Reais: R$ %.2f\n", total);
                    break;

                case 0:
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

        scanner.close();
    }
}
