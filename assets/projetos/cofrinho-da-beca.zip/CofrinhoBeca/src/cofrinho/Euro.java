package cofrinho;

/*Classe que representa a moeda Euro.*/
public class Euro extends Moeda {

    //Taxa de conversão usada para transformar Euro em Real
    private static final double TAXA_CONVERSAO = 6.33;

    /*Recebe o valor em euro que quer adicionar no cofrinho.*/
    public Euro(double valor) {
        super(valor);
    }

    /*Converte o valor para reais.
     * Fórmula: valor do euro × taxa de conversão.*/
    @Override
    public double converterParaReal() {
        return valor * TAXA_CONVERSAO;
    }

    @Override
    public String info() {
    	return "Euro - €: " + valor;
    }
}