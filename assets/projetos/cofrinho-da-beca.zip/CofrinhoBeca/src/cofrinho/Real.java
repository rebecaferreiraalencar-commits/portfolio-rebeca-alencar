package cofrinho;

/*Classe que representa a moeda Real (BRL).
 * Como já é a moeda base do sistema,
 * não precisa de taxa de conversão.*/
public class Real extends Moeda {

    /*Construtor do Real.
     * Recebe o valor em reais que adicionou no cofrinho.*/
    public Real(double valor) {
        super(valor);
    }

    /*o valor convertido é igual ao valor original.*/
    @Override
    public double converterParaReal() {
        return valor;
    }

    /* Retorna uma descrição da moeda para listagem.*/
    @Override
    public String info() {
        return "Real - R$: " + valor;
    }
}